# Sadie Implementation Notes

Sadie is intentionally small for the proof of concept. The important contract is not the initial storage engine or dashboard; it is the run record:

```text
suite + candidate + gate policy -> traces + scores + artifacts + release decision
```

## Extension Points

### Add a provider

Create a class implementing `ModelAdapter.complete()` and register it in `sadie.runner.adapter_for`.

### Add a scorer

Add a function to `sadie/scorers/base.py` and register it in `SCORERS`.

### Add a gate policy

Create a JSON file in `examples/gates/` or your production registry root.

## Production Hardening Checklist

- store run artifacts in object storage
- export traces to OpenTelemetry
- add human review labels for ambiguous failures
- maintain dev, validation, and release suites separately
- rotate red-team scenarios from incidents
- add secret scanning before publishing artifacts
- isolate live tools from CI dry-run tools
- measure cost per accepted answer, not just token cost
