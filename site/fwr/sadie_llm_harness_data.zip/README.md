# Sadie LLM Harness

Sadie is a proof-of-concept LLM evaluation harness for prompts, model providers, RAG workflows, tool-using agents, safety gates, and release decisions.

It is designed for GitHub-first workflows:

- version scenarios, suites, candidates, gates, and reports in a repository
- run smoke tests locally before prompt/model changes ship
- compare candidate behavior against explicit acceptance criteria
- emit traces, scores, artifacts, and a release decision record
- start with mock/API execution and grow into local vLLM or other OpenAI-compatible servers

## Quick Start

```bash
python -m sadie.cli validate --root examples
python -m sadie.cli run --root examples --suite support_regression --candidate sadie_mock --gate default_release
python -m sadie.cli report --run-dir runs/latest
```

The default candidate uses `MockAdapter`, so no API keys are required.

## Repository Layout

```text
sadie/
  adapters/       model provider adapters
  scorers/        deterministic and rubric-style scorers
  cli.py          command-line interface
  gates.py        release gate evaluation
  models.py       typed domain objects
  registry.py     scenario/suite/candidate/gate loading
  runner.py       harness execution engine
  reporting.py    HTML/JSON reporting
  tracing.py      JSONL span writer
examples/
  scenarios/      versioned test cases
  suites/         scenario collections
  candidates/     provider/model/prompt configurations
  gates/          release policy definitions
tests/            unit tests and smoke tests
docs/             implementation notes
```

## Concepts

### Scenario

A scenario describes one test case: input, expected behavior, safety constraints, scoring rules, and tags.

### Suite

A suite groups scenarios by workflow or release risk, such as support RAG, robotics safety, structured extraction, or prompt injection.

### Candidate

A candidate describes the system under test: provider adapter, model name, prompt version, parameters, tools, and retrieval configuration.

### Score

Sadie ships with dependency-free scorers:

- `contains_all`: required phrase/concept matching
- `not_contains_any`: prohibited text/policy checks
- `json_valid`: strict JSON output validation
- `tool_call_expected`: simple tool-call marker check
- `rubric_keywords`: weighted semantic proxy for proof-of-concept rubrics

### Gate

A gate maps scores into a release decision:

- `pass`
- `warn`
- `hold`
- `rollback`

Hard gates override aggregate readiness scores.

## OpenAI-Compatible Adapter

Sadie includes an HTTP adapter for any OpenAI-compatible `/v1/chat/completions` endpoint, including hosted APIs and local servers.

```json
{
  "id": "local_vllm",
  "provider": "openai_compatible",
  "model": "meta-llama/Llama-3.1-8B-Instruct",
  "endpoint": "http://localhost:8000/v1/chat/completions",
  "api_key_env": "LOCAL_LLM_API_KEY",
  "system_prompt": "You are Sadie, an evaluation candidate.",
  "parameters": {
    "temperature": 0.0,
    "max_tokens": 512
  }
}
```

## CI

The included GitHub Actions workflow runs validation and tests:

```bash
python -m sadie.cli validate --root examples
python -m unittest discover -s tests
```

## License

MIT. See `LICENSE`.
