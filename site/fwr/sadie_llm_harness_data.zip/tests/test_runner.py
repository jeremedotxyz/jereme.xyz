import tempfile
import unittest

from sadie.registry import Registry
from sadie.runner import Runner


class RunnerTests(unittest.TestCase):
    def test_mock_suite_runs_and_writes_artifacts(self):
        registry = Registry("examples")
        suite = registry.suite("support_regression")
        candidate = registry.candidate("sadie_mock")
        gate = registry.gate("default_release")
        with tempfile.TemporaryDirectory() as tmp:
            summary = Runner(registry, tmp).run(suite, candidate, gate)
            self.assertIn(summary.gate_decision, {"pass", "warn"})
            self.assertEqual(len(summary.results), 4)
            self.assertGreater(summary.average_score, 0.7)


if __name__ == "__main__":
    unittest.main()
