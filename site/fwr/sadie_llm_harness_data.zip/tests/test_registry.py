import unittest

from sadie.registry import Registry


class RegistryTests(unittest.TestCase):
    def test_examples_validate(self):
        registry = Registry("examples")
        self.assertEqual(registry.validate(), [])


if __name__ == "__main__":
    unittest.main()
