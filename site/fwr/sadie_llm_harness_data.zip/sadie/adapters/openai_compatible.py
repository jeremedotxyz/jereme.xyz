from __future__ import annotations

import json
import os
import urllib.error
import urllib.request

from sadie.adapters.base import ModelAdapter
from sadie.models import ModelRequest, ModelResponse


class OpenAICompatibleAdapter(ModelAdapter):
    """HTTP adapter for OpenAI-compatible chat completions endpoints."""

    def complete(self, request: ModelRequest) -> ModelResponse:
        candidate = request.candidate
        if not candidate.endpoint:
            raise ValueError("openai_compatible candidate requires an endpoint")

        messages = []
        if candidate.system_prompt:
            messages.append({"role": "system", "content": candidate.system_prompt})
        messages.append({"role": "user", "content": request.scenario.input})

        payload = {
            "model": candidate.model,
            "messages": messages,
            **candidate.parameters,
        }

        headers = {"Content-Type": "application/json"}
        if candidate.api_key_env:
            api_key = os.environ.get(candidate.api_key_env)
            if api_key:
                headers["Authorization"] = f"Bearer {api_key}"

        http_request = urllib.request.Request(
            candidate.endpoint,
            data=json.dumps(payload).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        try:
            with urllib.request.urlopen(http_request, timeout=120) as response:
                raw = json.loads(response.read().decode("utf-8"))
        except urllib.error.URLError as exc:
            raise RuntimeError(f"OpenAI-compatible request failed: {exc}") from exc

        text = raw["choices"][0]["message"]["content"]
        usage = raw.get("usage", {})
        return ModelResponse(
            text=text,
            raw=raw,
            tokens_in=int(usage.get("prompt_tokens", 0) or 0),
            tokens_out=int(usage.get("completion_tokens", 0) or 0),
        )
