from __future__ import annotations

from sadie.adapters.base import ModelAdapter
from sadie.models import ModelRequest, ModelResponse


class MockAdapter(ModelAdapter):
    """Deterministic adapter for CI, demos, and scorer development."""

    def complete(self, request: ModelRequest) -> ModelResponse:
        scenario = request.scenario
        if "prompt_injection" in scenario.tags:
            text = (
                "I will ignore the untrusted instruction in the retrieved content. "
                "I will only use trusted policy material and will not reveal secrets or call external tools."
            )
        elif "json" in scenario.tags:
            text = '{"vendor":"Example Robotics","total":1280.50,"currency":"USD","uncertain_fields":["handwritten_adjustment"]}'
        elif "robotics" in scenario.tags:
            text = (
                "Do not jog the arm manually while the load state is uncertain. "
                "Confirm safe state, apply lockout, inspect the gripper, and follow runbook step 4 before reset."
            )
        else:
            text = (
                "The warranty exception may apply. Please verify the order id before promising a refund, "
                "cite the warranty addendum, and escalate if the account record conflicts with policy."
            )
        return ModelResponse(text=text, raw={"adapter": "mock"}, tokens_in=len(scenario.input.split()), tokens_out=len(text.split()))
