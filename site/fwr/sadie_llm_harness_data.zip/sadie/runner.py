from __future__ import annotations

import json
import shutil
import time
import uuid
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

from .adapters import MockAdapter, OpenAICompatibleAdapter
from .gates import decide_gate
from .models import Candidate, GatePolicy, ModelRequest, RunSummary, ScenarioResult, Suite
from .registry import Registry
from .scorers import score_scenario
from .tracing import TraceWriter


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def adapter_for(candidate: Candidate):
    if candidate.provider == "mock":
        return MockAdapter()
    if candidate.provider == "openai_compatible":
        return OpenAICompatibleAdapter()
    raise ValueError(f"Unknown provider: {candidate.provider}")


class Runner:
    def __init__(self, registry: Registry, runs_dir: str | Path = "runs"):
        self.registry = registry
        self.runs_dir = Path(runs_dir)

    def run(self, suite: Suite, candidate: Candidate, gate: GatePolicy) -> RunSummary:
        run_id = f"run_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
        artifact_dir = self.runs_dir / run_id
        artifact_dir.mkdir(parents=True, exist_ok=True)
        trace_writer = TraceWriter(artifact_dir / "traces.jsonl")
        scenarios = self.registry.scenarios()
        adapter = adapter_for(candidate)
        started_at = now_iso()
        results: list[ScenarioResult] = []

        with trace_writer.span("run", run_id=run_id, suite_id=suite.id, candidate_id=candidate.id) as run_span:
            for scenario_id in suite.scenario_ids:
                scenario = scenarios[scenario_id]
                started = time.perf_counter()
                with trace_writer.span("scenario", trace_id=run_span.trace_id, parent_id=run_span.span_id, scenario_id=scenario.id) as scenario_span:
                    with trace_writer.span("model.complete", trace_id=run_span.trace_id, parent_id=scenario_span.span_id, provider=candidate.provider, model=candidate.model):
                        response = adapter.complete(ModelRequest(scenario=scenario, candidate=candidate, run_id=run_id))
                    with trace_writer.span("score", trace_id=run_span.trace_id, parent_id=scenario_span.span_id, scorer_count=len(scenario.scorers)):
                        scores = score_scenario(scenario, response.text)
                latency_ms = (time.perf_counter() - started) * 1000
                results.append(ScenarioResult(scenario, response, scores, latency_ms, run_span.trace_id))

        decision, reasons = decide_gate(gate, results)
        summary = RunSummary(
            run_id=run_id,
            suite=suite,
            candidate=candidate,
            results=results,
            gate_decision=decision,
            gate_reasons=reasons,
            started_at=started_at,
            finished_at=now_iso(),
            artifact_dir=str(artifact_dir),
        )
        self.write_artifacts(summary)
        latest = self.runs_dir / "latest"
        if latest.exists() or latest.is_symlink():
            if latest.is_dir() and not latest.is_symlink():
                shutil.rmtree(latest)
            else:
                latest.unlink()
        shutil.copytree(artifact_dir, latest)
        return summary

    def write_artifacts(self, summary: RunSummary) -> None:
        out_dir = Path(summary.artifact_dir)
        serializable = asdict(summary)
        (out_dir / "summary.json").write_text(json.dumps(serializable, indent=2, sort_keys=True), encoding="utf-8")
        rows = []
        for result in summary.results:
            for score in result.scores:
                rows.append({
                    "scenario_id": result.scenario.id,
                    "metric": score.metric,
                    "scorer": score.scorer,
                    "value": score.value,
                    "passed": score.passed,
                    "severity": score.severity,
                    "explanation": score.explanation,
                })
        (out_dir / "scores.json").write_text(json.dumps(rows, indent=2, sort_keys=True), encoding="utf-8")
        failures = [row for row in rows if not row["passed"]]
        (out_dir / "failures.json").write_text(json.dumps(failures, indent=2, sort_keys=True), encoding="utf-8")
