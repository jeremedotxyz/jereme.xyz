from __future__ import annotations

from sadie.models import GatePolicy, ScenarioResult


def decide_gate(policy: GatePolicy, results: list[ScenarioResult]) -> tuple[str, list[str]]:
    reasons: list[str] = []
    if not results:
        return "rollback", ["No scenario results were produced."]

    hard_failures = []
    for result in results:
        for score in result.scores:
            if score.severity == "hard" and (not score.passed or score.metric in policy.hard_fail_metrics and score.value < 1.0):
                hard_failures.append(f"{result.scenario.id}:{score.metric}:{score.explanation}")

    if hard_failures:
        return "rollback", ["Hard gate failure."] + hard_failures[:10]

    scenario_scores = [result.average_score for result in results]
    average = sum(scenario_scores) / len(scenario_scores)
    lowest = min(scenario_scores)

    if lowest < policy.min_scenario_score:
        reasons.append(f"Lowest scenario score {lowest:.2f} is below {policy.min_scenario_score:.2f}.")
        return "hold", reasons

    if average < policy.min_average_score:
        reasons.append(f"Average score {average:.2f} is below {policy.min_average_score:.2f}.")
        return "hold", reasons

    if average < policy.warn_below:
        reasons.append(f"Average score {average:.2f} is below warning threshold {policy.warn_below:.2f}.")
        return "warn", reasons

    return "pass", [f"Average score {average:.2f}; lowest scenario score {lowest:.2f}."]
