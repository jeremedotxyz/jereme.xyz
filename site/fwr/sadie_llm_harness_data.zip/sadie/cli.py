from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .registry import Registry
from .reporting import render_report
from .runner import Runner


def cmd_validate(args: argparse.Namespace) -> int:
    registry = Registry(args.root)
    errors = registry.validate()
    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1
    print(f"Validated registry at {args.root}")
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    registry = Registry(args.root)
    errors = registry.validate()
    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1
    suite = registry.suite(args.suite)
    candidate = registry.candidate(args.candidate)
    gate = registry.gate(args.gate)
    summary = Runner(registry, args.runs_dir).run(suite, candidate, gate)
    print(f"Run: {summary.run_id}")
    print(f"Decision: {summary.gate_decision}")
    print(f"Average score: {summary.average_score:.2f}")
    print(f"Pass rate: {summary.pass_rate:.0%}")
    print(f"Artifacts: {summary.artifact_dir}")
    return 0 if summary.gate_decision in {"pass", "warn"} or args.allow_hold else 2


def cmd_report(args: argparse.Namespace) -> int:
    out = render_report(args.run_dir)
    print(out)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="sadie", description="Sadie LLM Harness")
    sub = parser.add_subparsers(dest="command", required=True)

    validate = sub.add_parser("validate", help="Validate scenario registry")
    validate.add_argument("--root", default="examples")
    validate.set_defaults(func=cmd_validate)

    run = sub.add_parser("run", help="Run a suite against a candidate")
    run.add_argument("--root", default="examples")
    run.add_argument("--suite", required=True)
    run.add_argument("--candidate", required=True)
    run.add_argument("--gate", required=True)
    run.add_argument("--runs-dir", default="runs")
    run.add_argument("--allow-hold", action="store_true", help="Exit 0 even if gate returns hold/rollback")
    run.set_defaults(func=cmd_run)

    report = sub.add_parser("report", help="Render HTML report for a run directory")
    report.add_argument("--run-dir", default=str(Path("runs") / "latest"))
    report.set_defaults(func=cmd_report)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
