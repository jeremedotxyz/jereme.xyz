from __future__ import annotations

import html
import json
from pathlib import Path


def render_report(run_dir: str | Path) -> Path:
    run_path = Path(run_dir)
    summary = json.loads((run_path / "summary.json").read_text(encoding="utf-8"))
    scenario_averages = []
    passed_count = 0
    for result in summary["results"]:
        scores = result.get("scores", [])
        average = sum(score["value"] for score in scores) / max(len(scores), 1)
        scenario_averages.append(average)
        if scores and all(score["passed"] for score in scores):
            passed_count += 1
    average_score = sum(scenario_averages) / max(len(scenario_averages), 1)
    pass_rate = passed_count / max(len(summary["results"]), 1)
    rows = []
    for result in summary["results"]:
        scenario = result["scenario"]
        score_rows = "".join(
            f"<li><b>{html.escape(score['metric'])}</b>: {score['value']:.2f} "
            f"({'pass' if score['passed'] else 'fail'}) - {html.escape(score['explanation'])}</li>"
            for score in result["scores"]
        )
        rows.append(
            f"""
            <section class="scenario">
              <h3>{html.escape(scenario['title'])}</h3>
              <p class="meta">{html.escape(scenario['id'])} | {html.escape(scenario['category'])} | {result['latency_ms']:.1f} ms</p>
              <p><b>Input:</b> {html.escape(scenario['input'])}</p>
              <p><b>Output:</b> {html.escape(result['response']['text'])}</p>
              <ul>{score_rows}</ul>
            </section>
            """
        )

    page = f"""
    <!doctype html>
    <html lang="en">
    <head>
      <meta charset="utf-8">
      <title>Sadie Run Report {html.escape(summary['run_id'])}</title>
      <style>
        body {{ font-family: Arial, sans-serif; color: #18202b; margin: 40px; line-height: 1.45; }}
        header {{ border-bottom: 2px solid #d9dee5; margin-bottom: 24px; }}
        h1 {{ color: #123a5b; }}
        h2 {{ color: #256c91; }}
        .decision {{ display: inline-block; padding: 8px 12px; background: #e7f4f2; border: 1px solid #9ccbc5; font-weight: 700; }}
        .meta {{ color: #5b6472; font-size: 0.9em; }}
        .scenario {{ border-top: 1px solid #d9dee5; padding-top: 16px; margin-top: 16px; }}
        code {{ background: #f4f6f8; padding: 2px 4px; }}
      </style>
    </head>
    <body>
      <header>
        <p>fw/r (friends with robots)</p>
        <h1>Sadie LLM Harness Run Report</h1>
        <p class="meta">Run: <code>{html.escape(summary['run_id'])}</code></p>
      </header>
      <h2>Release Decision</h2>
      <p class="decision">{html.escape(summary['gate_decision'].upper())}</p>
      <ul>{''.join(f"<li>{html.escape(reason)}</li>" for reason in summary['gate_reasons'])}</ul>
      <h2>Summary</h2>
      <p>Suite: <b>{html.escape(summary['suite']['id'])}</b><br>
      Candidate: <b>{html.escape(summary['candidate']['id'])}</b><br>
      Average score: <b>{average_score:.2f}</b><br>
      Pass rate: <b>{pass_rate:.0%}</b></p>
      <h2>Scenario Results</h2>
      {''.join(rows)}
    </body>
    </html>
    """
    out = run_path / "report.html"
    out.write_text(page, encoding="utf-8")
    return out
