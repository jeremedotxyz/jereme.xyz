from __future__ import annotations

import json
from typing import Any

from sadie.models import Scenario, Score


def normalize(text: str) -> str:
    return " ".join(text.lower().split())


def contains_all(scenario: Scenario, output: str, config: dict[str, Any]) -> Score:
    required = [normalize(item) for item in config.get("phrases", [])]
    haystack = normalize(output)
    missing = [phrase for phrase in required if phrase not in haystack]
    value = 1.0 if not missing else max(0.0, 1.0 - len(missing) / max(len(required), 1))
    return Score(
        scenario_id=scenario.id,
        scorer="contains_all",
        metric=config.get("metric", "correctness"),
        value=value,
        passed=not missing,
        explanation="All required phrases present." if not missing else f"Missing required phrases: {missing}",
    )


def not_contains_any(scenario: Scenario, output: str, config: dict[str, Any]) -> Score:
    prohibited = [normalize(item) for item in config.get("phrases", [])]
    haystack = normalize(output)
    found = [phrase for phrase in prohibited if phrase in haystack]
    return Score(
        scenario_id=scenario.id,
        scorer="not_contains_any",
        metric=config.get("metric", "safety"),
        value=0.0 if found else 1.0,
        passed=not found,
        explanation="No prohibited phrases found." if not found else f"Found prohibited phrases: {found}",
        severity=config.get("severity", "hard"),
    )


def json_valid(scenario: Scenario, output: str, config: dict[str, Any]) -> Score:
    required_fields = config.get("required_fields", [])
    try:
        parsed = json.loads(output)
    except json.JSONDecodeError as exc:
        return Score(scenario.id, "json_valid", config.get("metric", "schema"), 0.0, False, f"Invalid JSON: {exc}", "hard")

    missing = [field for field in required_fields if field not in parsed]
    return Score(
        scenario_id=scenario.id,
        scorer="json_valid",
        metric=config.get("metric", "schema"),
        value=1.0 if not missing else 0.5,
        passed=not missing,
        explanation="Valid JSON." if not missing else f"Missing required fields: {missing}",
        severity=config.get("severity", "hard"),
    )


def tool_call_expected(scenario: Scenario, output: str, config: dict[str, Any]) -> Score:
    marker = normalize(config.get("marker", "TOOL_CALL:"))
    expected = bool(config.get("expected", True))
    present = marker in normalize(output)
    passed = present == expected
    return Score(
        scenario_id=scenario.id,
        scorer="tool_call_expected",
        metric=config.get("metric", "tool_use"),
        value=1.0 if passed else 0.0,
        passed=passed,
        explanation=f"Tool marker present={present}, expected={expected}.",
        severity=config.get("severity", "hard"),
    )


def rubric_keywords(scenario: Scenario, output: str, config: dict[str, Any]) -> Score:
    keywords = [normalize(item) for item in config.get("keywords", [])]
    threshold = float(config.get("threshold", 0.7))
    haystack = normalize(output)
    hits = [keyword for keyword in keywords if keyword in haystack]
    value = len(hits) / max(len(keywords), 1)
    return Score(
        scenario_id=scenario.id,
        scorer="rubric_keywords",
        metric=config.get("metric", "rubric"),
        value=value,
        passed=value >= threshold,
        explanation=f"Matched {len(hits)}/{len(keywords)} rubric keywords.",
        severity=config.get("severity", "normal"),
    )


SCORERS = {
    "contains_all": contains_all,
    "not_contains_any": not_contains_any,
    "json_valid": json_valid,
    "tool_call_expected": tool_call_expected,
    "rubric_keywords": rubric_keywords,
}


def score_scenario(scenario: Scenario, output: str) -> list[Score]:
    scores: list[Score] = []
    for config in scenario.scorers:
        scorer_type = config.get("type")
        scorer = SCORERS.get(scorer_type)
        if not scorer:
            scores.append(Score(scenario.id, "unknown", "configuration", 0.0, False, f"Unknown scorer type: {scorer_type}", "hard"))
            continue
        scores.append(scorer(scenario, output, config))
    return scores
