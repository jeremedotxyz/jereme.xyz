from __future__ import annotations

import json
import time
import uuid
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterator


@dataclass
class Span:
    trace_id: str
    span_id: str
    parent_id: str | None
    name: str
    started_at: float
    finished_at: float | None = None
    attributes: dict[str, Any] = field(default_factory=dict)


class TraceWriter:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    @contextmanager
    def span(self, name: str, trace_id: str | None = None, parent_id: str | None = None, **attributes: Any) -> Iterator[Span]:
        span = Span(
            trace_id=trace_id or uuid.uuid4().hex,
            span_id=uuid.uuid4().hex,
            parent_id=parent_id,
            name=name,
            started_at=time.time(),
            attributes=attributes,
        )
        try:
            yield span
        finally:
            span.finished_at = time.time()
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(asdict(span), sort_keys=True) + "\n")
