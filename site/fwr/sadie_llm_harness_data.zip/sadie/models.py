from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


Json = dict[str, Any]


@dataclass(frozen=True)
class Scenario:
    id: str
    version: str
    title: str
    category: str
    input: str
    expected_behavior: str
    data_classification: str = "synthetic"
    tags: list[str] = field(default_factory=list)
    scorers: list[Json] = field(default_factory=list)
    metadata: Json = field(default_factory=dict)


@dataclass(frozen=True)
class Suite:
    id: str
    version: str
    title: str
    scenario_ids: list[str]
    tags: list[str] = field(default_factory=list)
    owner: str | None = None


@dataclass(frozen=True)
class Candidate:
    id: str
    provider: str
    model: str
    system_prompt: str = ""
    endpoint: str | None = None
    api_key_env: str | None = None
    parameters: Json = field(default_factory=dict)
    metadata: Json = field(default_factory=dict)


@dataclass(frozen=True)
class GatePolicy:
    id: str
    version: str
    min_average_score: float = 0.8
    min_scenario_score: float = 0.6
    hard_fail_metrics: list[str] = field(default_factory=list)
    warn_below: float = 0.9


@dataclass
class ModelRequest:
    scenario: Scenario
    candidate: Candidate
    run_id: str


@dataclass
class ModelResponse:
    text: str
    raw: Json = field(default_factory=dict)
    tokens_in: int = 0
    tokens_out: int = 0
    cost_usd: float = 0.0


@dataclass
class Score:
    scenario_id: str
    scorer: str
    metric: str
    value: float
    passed: bool
    explanation: str = ""
    severity: str = "normal"


@dataclass
class ScenarioResult:
    scenario: Scenario
    response: ModelResponse
    scores: list[Score]
    latency_ms: float
    trace_id: str

    @property
    def average_score(self) -> float:
        if not self.scores:
            return 0.0
        return sum(score.value for score in self.scores) / len(self.scores)

    @property
    def passed(self) -> bool:
        return all(score.passed for score in self.scores)


@dataclass
class RunSummary:
    run_id: str
    suite: Suite
    candidate: Candidate
    results: list[ScenarioResult]
    gate_decision: str
    gate_reasons: list[str]
    started_at: str
    finished_at: str
    artifact_dir: str

    @property
    def average_score(self) -> float:
        if not self.results:
            return 0.0
        return sum(result.average_score for result in self.results) / len(self.results)

    @property
    def pass_rate(self) -> float:
        if not self.results:
            return 0.0
        return sum(1 for result in self.results if result.passed) / len(self.results)
