from __future__ import annotations

import json
from pathlib import Path
from typing import Any, TypeVar

from .models import Candidate, GatePolicy, Scenario, Suite

T = TypeVar("T")


class RegistryError(ValueError):
    pass


def load_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise RegistryError(f"Invalid JSON in {path}: {exc}") from exc


def require(data: dict[str, Any], key: str, path: Path) -> Any:
    if key not in data:
        raise RegistryError(f"{path} is missing required field '{key}'")
    return data[key]


def scenario_from_file(path: Path) -> Scenario:
    data = load_json(path)
    return Scenario(
        id=require(data, "id", path),
        version=require(data, "version", path),
        title=require(data, "title", path),
        category=require(data, "category", path),
        input=require(data, "input", path),
        expected_behavior=require(data, "expected_behavior", path),
        data_classification=data.get("data_classification", "synthetic"),
        tags=list(data.get("tags", [])),
        scorers=list(data.get("scorers", [])),
        metadata=dict(data.get("metadata", {})),
    )


def suite_from_file(path: Path) -> Suite:
    data = load_json(path)
    return Suite(
        id=require(data, "id", path),
        version=require(data, "version", path),
        title=require(data, "title", path),
        scenario_ids=list(require(data, "scenario_ids", path)),
        tags=list(data.get("tags", [])),
        owner=data.get("owner"),
    )


def candidate_from_file(path: Path) -> Candidate:
    data = load_json(path)
    return Candidate(
        id=require(data, "id", path),
        provider=require(data, "provider", path),
        model=require(data, "model", path),
        system_prompt=data.get("system_prompt", ""),
        endpoint=data.get("endpoint"),
        api_key_env=data.get("api_key_env"),
        parameters=dict(data.get("parameters", {})),
        metadata=dict(data.get("metadata", {})),
    )


def gate_from_file(path: Path) -> GatePolicy:
    data = load_json(path)
    return GatePolicy(
        id=require(data, "id", path),
        version=require(data, "version", path),
        min_average_score=float(data.get("min_average_score", 0.8)),
        min_scenario_score=float(data.get("min_scenario_score", 0.6)),
        hard_fail_metrics=list(data.get("hard_fail_metrics", [])),
        warn_below=float(data.get("warn_below", 0.9)),
    )


class Registry:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.scenarios_dir = self.root / "scenarios"
        self.suites_dir = self.root / "suites"
        self.candidates_dir = self.root / "candidates"
        self.gates_dir = self.root / "gates"

    def _load_by_id(self, directory: Path, item_id: str, loader):
        for path in sorted(directory.glob("*.json")):
            item = loader(path)
            if item.id == item_id:
                return item
        raise RegistryError(f"Could not find '{item_id}' in {directory}")

    def scenarios(self) -> dict[str, Scenario]:
        return {scenario_from_file(path).id: scenario_from_file(path) for path in sorted(self.scenarios_dir.glob("*.json"))}

    def suite(self, suite_id: str) -> Suite:
        return self._load_by_id(self.suites_dir, suite_id, suite_from_file)

    def candidate(self, candidate_id: str) -> Candidate:
        return self._load_by_id(self.candidates_dir, candidate_id, candidate_from_file)

    def gate(self, gate_id: str) -> GatePolicy:
        return self._load_by_id(self.gates_dir, gate_id, gate_from_file)

    def validate(self) -> list[str]:
        errors: list[str] = []
        for directory in [self.scenarios_dir, self.suites_dir, self.candidates_dir, self.gates_dir]:
            if not directory.exists():
                errors.append(f"Missing directory: {directory}")
        if errors:
            return errors

        scenarios = self.scenarios()
        for path in sorted(self.suites_dir.glob("*.json")):
            suite = suite_from_file(path)
            for scenario_id in suite.scenario_ids:
                if scenario_id not in scenarios:
                    errors.append(f"Suite {suite.id} references unknown scenario {scenario_id}")

        for path in sorted(self.scenarios_dir.glob("*.json")):
            scenario = scenario_from_file(path)
            if not scenario.scorers:
                errors.append(f"Scenario {scenario.id} has no scorers")
            for scorer in scenario.scorers:
                if "type" not in scorer:
                    errors.append(f"Scenario {scenario.id} has scorer without type")

        return errors
